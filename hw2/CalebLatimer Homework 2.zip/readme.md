# Homework 2: CSS
This assignment was similar to the first but making a stronger case for css. I made use of the following to do this assignment: 

pure.css

Vanilla JS

jQuery
